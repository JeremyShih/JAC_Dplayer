module.exports = {
    plugins: {
        'autoprefixer': {}
    }
};